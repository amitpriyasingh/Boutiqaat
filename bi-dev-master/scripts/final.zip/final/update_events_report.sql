alter table events_report modify column event_id varchar(100);
update events_report h 
left join (select * from CELEBRITY_GROUP where GROUPID <> 13) cmap on h.celebrity_id = cmap.CELEBID 
left join CELEB_GROUPS cord on cord.ID = cmap.GROUPID 
set 
h.event_id = concat(h.celebrity_id, "---", h.event_portal, "---", h.event_type, "---", h.event_date, "---", h.event_time), 
h.account_manager = cord.NAME_E;
