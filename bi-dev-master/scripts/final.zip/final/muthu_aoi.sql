insert into test (
  order_date, 
  yearmonth , 
  order_year , 
  order_week , 
  order_month , 
  branch_id , 
  store_id , 
  order_number , 
  device_type , 
  payment_method_id , 
  payment_method , 
  line_id , 
  sku , 
  sku_name , 
  sku_barcode , 
  item_cost , 
  new_price , 
  sales_price , 
  unit_price , 
  last_order_price , 
  category1 , 
  category2, 
  category3 , 
  category4 , 
  brand_id , 
  brand_name , 
  box_id , 
  box_price , 
  box_discount , 
  box_name , 
  discount , 
  quantity , 
  box_quantity , 
  item_total , 
  order_discount , 
  order_total , 
  order_gmv , 
  customer_name , 
  customer_telephone , 
  order_mobile , 
  is_cancelled , 
  is_returned , 
  is_b_fulfilled , 
  order_ref_no , 
  celebrity_name , 
  celebrity_id , 
  celebrity_price , 
  celebrity_commission , 
  order_region , 
  city , 
  country , 
  is_celebrity , 
  currency_id , 
  currency , 
  currency_rate , 
  ex_rate , 
  awbstatus , 
  awbnumber , 
  return_awbnumber , 
  driver_id , 
  runsheet_no , 
  non_inventory , 
  status , 
  status_group,
  supplier_id , 
  supplier_name , 
  supplier_acc_no , 
  soh , 
  sales_period , 
  last_grn_date,
  ageing,
  ageing_month
  
)
SELECT 
     ISSUE_1.VDATE,
     year(ISSUE_1.VDATE)+month(ISSUE_1.VDATE) * 10000,
     year(ISSUE_1.VDATE), 
     week(ISSUE_1.VDATE), 
     month(ISSUE_1.VDATE),
     ISSUE_1.PCENTER BRANCHID,
     ISSUE_2.PRODS,
     ISSUE_1.BILNO cust,
     ISSUE_1.DV_OS_TYPE,
     (CASE ISSUE_1.PAYMENT WHEN 0 THEN 2 ELSE ISSUE_1.PAYMENT END ),
     (CASE ISSUE_1.PAYMENT WHEN 0 THEN 'CASH on Delivery' ELSE CASH_PAYMENTS_NAME_E END),
     ISSUE_2.ID LINEID,
     IFNULL(ITEMS_ASSEM.prodn1,items.PRODN) SKU,
     items.PRODNAME_E,
     items.PAR_CODE,
     (CASE item_prods.COST WHEN 0 THEN ISSUE_2.ITEM_COST ELSE item_prods.COST END ) ,
     items.SAL_PRICE,
     IF(bp.cal_price IS NULL, items.SAL_PRICE, IF(ITEMS_ASSEM.FREE_PRICE_SW IS NULL OR ITEMS_ASSEM.FREE_PRICE_SW=1,0,(items.SAL_PRICE*ISSUE_2.PRICE/(bp.cal_price)))),
     ISSUE_2.PRICE,
     items.LAST_ORDER_PRICE,
     PRODUCT_CAT1.NAME_E,
     PRODUCT_CAT2.NAME_E,
     PRODUCT_CAT3.NAME_E,
     PRODUCT_CAT4.NAME_E,
     items.BRAND_ID,
     MK_BRANDS.NAME_E,
     NULL,
     NULL,
     NULL,
     NULL,
     ISSUE_2.DISC2,
     ISSUE_2.QTY,
     NULL,
     ISSUE_2.PRICE*ISSUE_2.QTY,
     
     ISSUE_1.DISCOUNT,
     ISSUE_1.TOTAL,
     (ISSUE_1.TOTAL - coalesce(ISSUE_1.DISCOUNT,0)),
     ISSUE_1.CUSTOMER_NAME,
     ISSUE_1.CUST_TEL,
     ISSUE_1.ORDER_MOBILE,
     (CASE ISSUE_1.ORDER_STAT WHEN 'Canceled'THEN 1 WHEN 'CancelRq' THEN 1 ELSE 0 END ),
     (CASE ISSUE_1.ORDER_STAT WHEN 'Returned' THEN 1 ELSE 0 END ),
     (CASE ISSUE_1.ORDER_STAT WHEN 'Deliverd' THEN 1 ELSE 0 END ),
     ISSUE_1.ORDER_REF_NO,
     MK_CELEB.NAME_E,
     ISSUE_2.CATEGORY_ID,
     ISSUE_2.CELEBRITY_PRICE,
     0.1*ISSUE_2.PRICE*ISSUE_2.QTY,
     ISSUE_1.ORDER_REGION,
     ISSUE_1.ORDER_AREA,
     centers_NAME_E,
     (CASE ISSUE_2.CATEGORY_ID WHEN NULL THEN 0 ELSE 1 END ),
     ISSUE_1.CURR_ID,
     CURR_NAME_E,
     ISSUE_1.CURR_RATE,
     CURRANCY_EX_RATE,
     ISSUE_1.AWBSTATUS,
     ISSUE_1.AWBNUMBER,
     ISSUE_1.RETURN_AWBNUMBER,
     ISSUE_1.DRIVER_NO,
     ISSUE_1.SHEET_ID,
     ISSUE_2.NON_INVENT,
     ISSUE_1.ORDER_STAT,
     (CASE  ISSUE_1.ORDER_STAT 
       WHEN 'Canceled' THEN 'Cancelled'
       WHEN 'Hold' THEN 'Hold'
       WHEN 'WH-Hold' THEN 'Hold'
       WHEN 'HoldConfirmed ' THEN 'Hold'
       WHEN '%' THEN 'Cancelled'
       WHEN 'Returned' THEN 'Returned'
       WHEN 'Deliverd' THEN 'Success'
       WHEN 'Paid' THEN 'Success'
       WHEN 'Shipped' THEN 'Success'
       WHEN 'Confirmed' THEN 'Unshipped'
       WHEN 'Invoiced' THEN 'Unshipped'
       WHEN 'PreConfirmed' THEN 'Unshipped'
       WHEN 'Received' THEN 'Unshipped'
       WHEN 'Shelved' THEN 'Unshipped'
       WHEN 'Reschedule' THEN 'Unshipped'
       WHEN 'ScheduleRq' THEN 'Cancelled'
       WHEN 'Cancel Rq' THEN 'Cancelled'
       WHEN 'CancelRq' THEN 'Cancelled'
       ELSE 'Not Specified' END),
     items.VENDOR,
     SUPPLIERS.NAME_E,
     SUPPLIERS.ACCNO,
     items.HOLD_QTY,
     datediff(items.LAST_ORDER_DATE , items.ADD_DT),
     if(items.LAST_ORDER_DATE>ISSUE_1.VDATE,ISSUE_1.VDATE,items.LAST_ORDER_DATE),
     items.LAST_GRN_DATE,
     datediff(ISSUE_1.VDATE, items.LAST_GRN_DATE),
     if(datediff(DATE_SUB(ISSUE_1.VDATE, INTERVAL DAYOFMONTH(ISSUE_1.VDATE)-1 DAY), items.LAST_GRN_DATE)  > 0,  datediff(DATE_SUB(ISSUE_1.VDATE, INTERVAL DAYOFMONTH(ISSUE_1.VDATE)-1 DAY), items.LAST_GRN_DATE),0)
     
     FROM
     
     (select ISSUE_1.TIME_STAMP, ISSUE_1.VDATE, ISSUE_1.PCENTER, ISSUE_1.BILNO, ISSUE_1.DV_OS_TYPE, ISSUE_1.PAYMENT, ISSUE_1.DISCOUNT, ISSUE_1.CODE,
     ISSUE_1.TOTAL,
     ISSUE_1.CUSTOMER_NAME,
     ISSUE_1.CUST_TEL,
     ISSUE_1.ORDER_MOBILE, ISSUE_1.ORDER_STAT,
     ISSUE_1.ORDER_REF_NO,
     ISSUE_1.ORDER_REGION,
     ISSUE_1.ORDER_AREA,
     centers.NAME_E centers_NAME_E,
     ISSUE_1.CURR_ID,
     CASH_PAYMENTS.NAME_E CASH_PAYMENTS_NAME_E,
     CURRANCY.NAME_E CURR_NAME_E,
     ISSUE_1.CURR_RATE,
     CURRANCY.EX_RATE CURRANCY_EX_RATE,
     ISSUE_1.AWBSTATUS,
     ISSUE_1.AWBNUMBER,
     ISSUE_1.RETURN_AWBNUMBER,
     ISSUE_1.DRIVER_NO,
     ISSUE_1.SHEET_ID
     from ISSUE_1 
     LEFT JOIN CASH_PAYMENTS ON ISSUE_1.PAYMENT = CASH_PAYMENTS.ID
     LEFT JOIN CURRANCY ON ISSUE_1.CURR_ID = CURRANCY.ID
     LEFT JOIN centers ON ISSUE_1.PCENTER = centers.ID 
     WHERE ISSUE_1.VDATE between '2017-02-22 00:00:00.000000' and '2017-02-26 00:00:00.000000' AND ISSUE_1.CODE = 72)
    ISSUE_1
    JOIN ISSUE_2  force index (PRODN_IDX) ON ISSUE_1.BILNO = ISSUE_2.BILNO
       AND ISSUE_1.CODE = ISSUE_2.CODE
       AND ISSUE_1.PCENTER = ISSUE_2.PCENTER AND ISSUE_2.PRODN NOT IN ('SHIPPINGBTQ','SHIPPINGSKU','SHIPPINGQATAR')
    
     LEFT JOIN (SELECT boxno, SUM(IF(ITEMS_ASSEM.FREE_PRICE_SW=1,0,(ITEMS_ASSEM.QTY*box_items.SAL_PRICE))) cal_price from 
              (SELECT ITEMS_ASSEM.PRODN, prodn1 boxno, QTY, FREE_PRICE_SW
              FROM ITEMS_ASSEM
              WHERE prodn1 in (select PRODN from ISSUE_2 where (BILNO,CODE,PCENTER) in (SELECT BILNO,CODE,PCENTER from ISSUE_1 where ISSUE_1.VDATE between '2017-02-22 00:00:00.000000' and '2017-02-26 00:00:00.000000' AND ISSUE_1.CODE = 72))
              ) ITEMS_ASSEM
              JOIN items box_items ON box_items.PRODN=boxno AND box_items.NON_INVENTORY_ITEM = 4
              GROUP BY ITEMS_ASSEM.PRODN) bp ON bp.boxno = ISSUE_2.PRODN
     LEFT JOIN MK_CELEB ON ISSUE_2.CATEGORY_ID = MK_CELEB.ID
     LEFT JOIN items ON items.PRODN = ISSUE_2.PRODN
     LEFT JOIN MK_BRANDS  ON items.BRAND_ID = MK_BRANDS.ID
     LEFT JOIN PRODUCT_CAT1 FORCE INDEX(PRIMARY) ON items.CAT1 = PRODUCT_CAT1.ID
     LEFT JOIN PRODUCT_CAT2 FORCE INDEX(PRIMARY) ON items.CAT2 = PRODUCT_CAT2.ID
     LEFT JOIN PRODUCT_CAT3 FORCE INDEX(PRIMARY) ON items.CAT3 = PRODUCT_CAT3.ID
     LEFT JOIN PRODUCT_CAT4 FORCE INDEX(PRIMARY) ON items.CAT4 = PRODUCT_CAT4.ID
     LEFT JOIN SUPPLIERS ON items.VENDOR = SUPPLIERS.ID
     LEFT JOIN item_prods ON items.PRODN = item_prods.PRODN AND item_prods.PRODS = 1
     LEFT JOIN ITEMS_ASSEM on ITEMS_ASSEM.PRODN = items.PRODN
     GROUP BY ISSUE_2.PRODN, ITEMS_ASSEM.prodn1;