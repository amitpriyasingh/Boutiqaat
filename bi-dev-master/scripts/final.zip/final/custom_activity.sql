DROP TABLE if exists c_activity;
CREATE TABLE `c_activity` (
  `id` int(10) AUTO_INCREMENT,
  `customer_id` int(10) unsigned DEFAULT NULL COMMENT 'Customer Id',
  `customer_email` varchar(255) DEFAULT NULL,
  `telephone_no` varchar(255) UNIQUE DEFAULT NULL,
  `first_order_date` timestamp NULL DEFAULT NULL COMMENT 'Created At',
  `order_number` int(10) unsigned UNIQUE NOT NULL COMMENT 'Order Number or BiLNO in ISSUE_1',
  `country` varchar(255) DEFAULT NULL COMMENT 'From Pcenter',
  PRIMARY KEY (id)
);

INSERT INTO c_activity (customer_id, telephone_no, first_order_date, order_number, country)
SELECT m.CUSTNO, m.CUST_TEL, m.VDATE first_order_date, m.BILNO,
(case m.PCENTER when '1' THEN 'Kuwait'
  when '2' THEN 'Qatar'
  when '3' THEN 'UAE'
  when '4' THEN 'KSA'
  when '5' THEN 'Bahrain'
  when '6' THEN 'Oman'
  when '7' THEN 'International'
  when '8' THEN 'Celebrities'
  when '9' THEN 'Replacement'
  when '10' THEN 'Rose Dome '
  else 'Unspecified'
end )
 FROM ISSUE_1 m
JOIN (SELECT min(VDATE) fod, CUST_TEL cid FROM ISSUE_1 WHERE CUST_TEL is not NULL group by cid) min 
ON m.VDATE = min.fod AND m.CUST_TEL = min.cid GROUP BY m.CUST_TEL;
