drop table if exists events_report;

CREATE TABLE `events_report` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `event_id` varchar(50) NOT NULL DEFAULT '',
  `user_name` varchar(55) DEFAULT NULL,
  `celebrity_name` varchar(55) DEFAULT NULL,
  `celebrity_id` int(10) unsigned DEFAULT NULL,
  `generic` varchar(55) DEFAULT NULL,
  `event_portal` varchar(50) DEFAULT NULL,
  `event_type` varchar(50) DEFAULT NULL,
  `event_class` varchar(50) DEFAULT NULL,
  `bq_post` int(10) unsigned NOT NULL,
  `total_post` int(10) unsigned NOT NULL,
  `event_date` date DEFAULT NULL,
  `event_time` time(6) DEFAULT NULL,
  `created_at` datetime(6) DEFAULT NULL,
  `updated_at` datetime(6) DEFAULT NULL,
  `event_hours` int(10) unsigned DEFAULT NULL,
  `event_minutes` int(10) unsigned DEFAULT NULL,
  `remark` longtext NOT NULL,
  `labelid` varchar(50) DEFAULT NULL,
  `productid` varchar(64) DEFAULT NULL,
  `category1` varchar(100) DEFAULT NULL,
  `category2` varchar(100) DEFAULT NULL,
  `category3` varchar(100) DEFAULT NULL,
  `category4` varchar(100) DEFAULT NULL,
  `brand` varchar(50) DEFAULT NULL,
  `account_manager` varchar(50) DEFAULT NULL,
  PRIMARY KEY (`id`)
);


#INSERT FROM events_data to events_report

insert into events_report( 
event_id, 
user_name, 
celebrity_name, 
celebrity_id, 
event_portal, 
event_type, 
event_class, 
bq_post, 
total_post, 
event_date, 
event_time, 
created_at, 
remark, 
labelid, 
productid, 
account_manager,
category1, 
category2, 
category3, 
category4, 
brand)
select event.* , sku_details.cat1, sku_details.cat2, sku_details.cat3, sku_details.cat4, sku_details.brand from
(select  
	concat(ed.event_date, "---", ed.event_id, "---", ed.celebrity_id), 
	ed.user_name, 
	ed.celebrity_name, 
	ed.celebrity_id, 
	ed.event_portal, 
	ed.event_type, 
	ed.event_class, 
	ed.bq_post, 
	ed.total_post, 
	ed.event_date, 
	ed.event_time, 
	ed.created_at, 
	ed.remark , 
	(case when ed.labelid is NULL then s.label 
      when ed.labelid = 'All' then 'All' 
      else ed.labelid end) labelid,
   (case when ed.productid is NULL then l.sku 
	  when ed.productid ='All' then 'All'
     else ed.productid end) skuid,
     cord.coordinator_id
from events_data ed 
left join events.magento_celeb_prod s on ed.productid=s.sku and s.celebrity_id = ed.celebrity_id and s.celebrity_name = ed.celebrity_name
left join events.magento_celeb_prod l on ed.labelid=l.label and l.celebrity_id = ed.celebrity_id and l.celebrity_name = ed.celebrity_name
left join celebrity_coordinator cord on cord.celebrity_id = ed.celebrity_id
group by event_id, skuid, labelid) event
left join (select i.PRODN skuid, c1.NAME_E cat1, c2.NAME_E cat2, c3.NAME_E cat3, c4.NAME_E cat4, brn.NAME_E brand from ITEMS i 
					left join PRODUCT_CAT1 c1 on i.CAT1=c1.ID
					left join PRODUCT_CAT2 c2 on i.CAT2=c2.ID
					left join PRODUCT_CAT3 c3 on i.CAT3=c3.ID
					left join PRODUCT_CAT4 c4 on i.CAT4=c4.ID
					left join MK_BRANDS brn on i.BRAND_ID=brn.ID
					group by i.PRODN) sku_details on sku_details.skuid = event.skuid;


#insert from base tables to events_report

insert into events_report( 
event_id, 
user_name, 
celebrity_name, 
celebrity_id, 
generic,
event_portal, 
event_type, 
event_class, 
bq_post, 
total_post, 
event_date, 
event_time, 
created_at, 
updated_at, 
event_hours, 
event_minutes, 
remark, 
labelid, 
productid, 
account_manager,
category1, 
category2, 
category3, 
category4, 
brand)
select event.* , sku_details.cat1, sku_details.cat2, sku_details.cat3, sku_details.cat4, sku_details.brand from 
(select concat(h.event_date, "---", h.id, "---", h.celebrity_id) event_id, h.user_name, h.celebrity_name, h.celebrity_id , h.generic , h.event_portal, h.event_type, h.event_class, h.bq_post, h.total_post, h.event_date, h.event_time, h.created_at, h.updated_at,h.event_hours, h.event_minutes, h.remark, 
(case when labelid is NULL then s.label 
      when labelid = 'All' then 'All' 
      else labelid end) labelid,
(case when skuid is NULL then l.sku 
	  when skuid ='All' then 'All'
     else skuid end) skuid,
cord.coordinator_id
from events.events_header h 
left join events.events_label_details d on h.id = d.event_id 
left join events.magento_celeb_prod s on d.skuid=s.sku and s.celebrity_id = h.celebrity_id and s. celebrity_name = h.celebrity_name
left join events.magento_celeb_prod l on d.labelid=l.label and l.celebrity_id = h.celebrity_id and l.celebrity_name = h.celebrity_name 
left join celebrity_coordinator cord on cord.celebrity_id = h.celebrity_id 
group by event_id, skuid, labelid) event
left join (select i.PRODN skuid, c1.NAME_E cat1, c2.NAME_E cat2, c3.NAME_E cat3, c4.NAME_E cat4, brn.NAME_E brand from ITEMS i 
					left join PRODUCT_CAT1 c1 on i.CAT1=c1.ID
					left join PRODUCT_CAT2 c2 on i.CAT2=c2.ID
					left join PRODUCT_CAT3 c3 on i.CAT3=c3.ID
					left join PRODUCT_CAT4 c4 on i.CAT4=c4.ID
					left join MK_BRANDS brn on i.BRAND_ID=brn.ID
					group by i.PRODN) sku_details on sku_details.skuid = event.skuid;
